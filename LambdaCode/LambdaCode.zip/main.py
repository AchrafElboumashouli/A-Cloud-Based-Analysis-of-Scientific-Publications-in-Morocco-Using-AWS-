import json
import boto3
from bronze_to_silver_etl import lambda_handler as decompress_handler

def lambda_handler(event, context):
    try:
        # Extract bucket name and file key from the S3 event
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        file_key = event['Records'][0]['s3']['object']['key']

        # Ensure the file is in the bronze folder
        if not file_key.startswith('1-bronze/'):
            return {
                'statusCode': 400,
                'body': json.dumps('File is not in the bronze folder.')
            }

        # Prepare the event for the decompression script
        decompress_event = {
            "bucket_name": bucket_name,
            "file_key": file_key,  # Pass the specific file key
            "destination_folder": "2-silver/"
        }

        # Step 1: Call the decompression script
        print("Starting decompression process...")
        decompress_response = decompress_handler(decompress_event, context)
        
        # Check if decompression was successful
        if decompress_response.get('statusCode') != 200:
            raise Exception(f"Decompression failed: {decompress_response.get('body')}")
        
        print("Decompression completed successfully:", decompress_response.get('body'))

        # Step 2: Trigger the Glue workflow
        glue_client = boto3.client('glue')
        workflow_name = 'workflow_scopus'

        # Start the workflow
        response = glue_client.start_workflow_run(Name=workflow_name)
        workflow_run_id = response['RunId']
        print(f"Started workflow: {workflow_name}, Run ID: {workflow_run_id}")

        return {
            'statusCode': 200,
            'body': f"Decompression and workflow started successfully. Workflow Run ID: {workflow_run_id}"
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Orchestration failed.',
                'error': str(e)
            })
        }